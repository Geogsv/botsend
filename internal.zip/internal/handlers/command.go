package handlers

import (
	"log"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"botresend/internal/config"
	"botresend/internal/utils"
)

// Глобальная переменная для хранения настроенной клавиатуры
var mainKeyboard tgbotapi.ReplyKeyboardMarkup

// SetupKeyboard инициализирует основную клавиатуру бота.
func SetupKeyboard(cfg *config.Config) {
	mainKeyboard = tgbotapi.NewReplyKeyboard(
		tgbotapi.NewKeyboardButtonRow(
			tgbotapi.NewKeyboardButton(cfg.JokeButtonText),
		),
		tgbotapi.NewKeyboardButtonRow(
			tgbotapi.NewKeyboardButton(cfg.HelpButtonText),
		),
	)
	mainKeyboard.ResizeKeyboard = true
	log.Println("Клавиатура ReplyKeyboardMarkup настроена.")
}

// SendStartMessage отправляет приветственное сообщение с клавиатурой.
func SendStartMessage(bot *tgbotapi.BotAPI, chatID int64, cfg *config.Config) {
	responseText := utils.GetRandomString(cfg.StartResponses)
	msg := tgbotapi.NewMessage(chatID, responseText)
	msg.ReplyMarkup = mainKeyboard // Прикрепляем клавиатуру
	_, err := bot.Send(msg)
	if err != nil {
		log.Printf("Ошибка отправки стартового сообщения для chatID %d: %v", chatID, err)
	}
}

// SendHelpMessage отправляет сообщение помощи с клавиатурой.
func SendHelpMessage(bot *tgbotapi.BotAPI, chatID int64, cfg *config.Config) {
	msg := tgbotapi.NewMessage(chatID, cfg.HelpText)
	msg.ReplyMarkup = mainKeyboard // Прикрепляем клавиатуру
	_, err := bot.Send(msg)
	if err != nil {
		log.Printf("Ошибка отправки сообщения помощи для chatID %d: %v", chatID, err)
	}
}

// HandleCommand обрабатывает команды /start и /help.
func HandleCommand(bot *tgbotapi.BotAPI, message *tgbotapi.Message, cfg *config.Config) {
	command := message.Command()
	chatID := message.Chat.ID
	log.Printf("[%s (%d)] Получена команда: /%s", message.From.UserName, message.From.ID, command)

	switch command {
	case "start":
		SendStartMessage(bot, chatID, cfg)
	case "help":
		SendHelpMessage(bot, chatID, cfg)
	default:
		msg := tgbotapi.NewMessage(chatID, "Эмм... Я не понял команды 🤔 Попробуй /start или нажми кнопки внизу.")
		_, err := bot.Send(msg)
		if err != nil {
			log.Printf("Ошибка отправки ответа на неизвестную команду /%s для chatID %d: %v", command, chatID, err)
		}
	}
}