package handlers

import (
	"log"
	"strings"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"botresend/internal/config" // <-- ЗАМЕНИТЕ relaybot на ваш путь модуля
	"botresend/internal/utils"  // <-- ЗАМЕНИТЕ relaybot на ваш путь модуля
)

// IsJokeRequest проверяет, является ли текст запросом на анекдот (по ключевым словам).
func IsJokeRequest(text string, cfg *config.Config) bool {
	if text == "" {
		return false
	}
	lowerText := strings.ToLower(strings.TrimSpace(text))
	for _, keyword := range cfg.JokeKeywords {
		if lowerText == keyword {
			return true
		}
	}
	return false
}

// SendRandomJoke отправляет случайный анекдот.
func SendRandomJoke(bot *tgbotapi.BotAPI, chatID int64, cfg *config.Config) {
	if len(cfg.Jokes) == 0 {
		msg := tgbotapi.NewMessage(chatID, utils.GetRandomString(cfg.NoJokesResponses))
		_, err := bot.Send(msg)
		if err != nil {
			log.Printf("Ошибка отправки сообщения об отсутствии анекдотов в чат %d: %v", chatID, err)
		}
		return
	}

	intro := utils.GetRandomString(cfg.JokeIntros)
	joke := utils.GetRandomString(cfg.Jokes)
	outro := utils.GetRandomString(cfg.JokeOutros)

	fullJokeText := intro + "\n\n" + joke
	if outro != "" {
		fullJokeText += "\n\n" + outro
	}

	log.Printf("Отправка анекдота в чат %d", chatID)
	msg := tgbotapi.NewMessage(chatID, fullJokeText)
	_, err := bot.Send(msg)
	if err != nil {
		log.Printf("Ошибка отправки анекдота в чат %d: %v", chatID, err)
	}
}