package handlers

import (
	"log"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"botresend/internal/config" // <-- ЗАМЕНИТЕ relaybot на ваш путь модуля
)

// ForwardAndDeleteMessage пересылает сообщение получателю и удаляет оригинал.
func ForwardAndDeleteMessage(bot *tgbotapi.BotAPI, message *tgbotapi.Message, cfg *config.Config) {
	senderChatID := message.Chat.ID
	senderMessageID := message.MessageID
	senderUserID := message.From.ID

	messageType := getMessageType(message)

	log.Printf("[%s (%d)] Получено сообщение (тип: %s, ID: %d). Пересылка для %d...", message.From.UserName, senderUserID, messageType, senderMessageID, cfg.RecipientUserID)

	// 1. Пересылаем сообщение
	forwardConfig := tgbotapi.NewForward(cfg.RecipientUserID, senderChatID, senderMessageID)

	_, err := bot.Send(forwardConfig)
	if err != nil {
		log.Printf("ОШИБКА: Не удалось переслать сообщение %d (тип: %s) от %d для %d: %v", senderMessageID, messageType, senderUserID, cfg.RecipientUserID, err)
	} else {
		log.Printf("Сообщение %d (тип: %s) от %d успешно переслано %d.", senderMessageID, messageType, senderUserID, cfg.RecipientUserID)
	}

	// 2. Удаляем исходное сообщение отправителя
	deleteMsg := tgbotapi.NewDeleteMessage(senderChatID, senderMessageID)
	_, err = bot.Send(deleteMsg)
	if err != nil {
		log.Printf("ПРЕДУПРЕЖДЕНИЕ: Не удалось удалить исходное сообщение %d (тип: %s) в чате %d от %d: %v", senderMessageID, messageType, senderChatID, senderUserID, err)
	} else {
		log.Printf("Исходное сообщение %d (тип: %s) от %d удалено из чата %d.", senderMessageID, messageType, senderUserID, senderChatID)
	}
}

// getMessageType определяет тип сообщения для логирования.
func getMessageType(message *tgbotapi.Message) string {
	if len(message.Photo) > 0 {
		return "фото"
	} else if message.Sticker != nil {
		return "стикер"
	} else if message.Video != nil {
		return "видео"
	} else if message.Document != nil {
		return "документ"
	} else if message.Audio != nil {
		return "аудио"
	} else if message.Voice != nil {
		return "голосовое"
	} else if message.Text != "" {
		return "текст"
	}
	return "неизвестный"
}