package bot

import (
	"log"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"botresend/internal/config"
	"botresend/internal/handlers"
)

type Bot struct {
	api *tgbotapi.BotAPI
	cfg *config.Config
}

func NewBot(cfg *config.Config) (*Bot, error) {
	api, err := tgbotapi.NewBotAPI(cfg.BotToken)
	if err != nil {
		return nil, err
	}
	api.Debug = cfg.DebugMode

	log.Printf("Авторизован как %s", api.Self.UserName)

	// ИНИЦИАЛИЗАЦИЯ КЛАВИАТУРЫ
	handlers.SetupKeyboard(cfg)

	return &Bot{
		api: api,
		cfg: cfg,
	}, nil
}

// Run запускает основной цикл обработки обновлений бота.
func (b *Bot) Run() {
	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60
	updates := b.api.GetUpdatesChan(u)

	log.Println("Бот запущен и ожидает сообщений...")

	for update := range updates {
		if update.Message == nil { // Обрабатываем только новые сообщения
			continue
		}

		messageText := update.Message.Text // Текст сообщения для проверок

		// Маршрутизация к обработчикам
		switch {
		case update.Message.IsCommand(): // 1. Обработка команд (/start, /help)
			handlers.HandleCommand(b.api, update.Message, b.cfg)

		case messageText == b.cfg.JokeButtonText: // 2. Нажата кнопка "Рассказать анекдот"
			handlers.SendRandomJoke(b.api, update.Message.Chat.ID, b.cfg)
		case messageText == b.cfg.HelpButtonText: // 3. Нажата кнопка "Помощь"
			handlers.SendHelpMessage(b.api, update.Message.Chat.ID, b.cfg)

		case handlers.IsJokeRequest(messageText, b.cfg): // 4. Проверка на ключевые слова (опционально)
			handlers.SendRandomJoke(b.api, update.Message.Chat.ID, b.cfg)

		default: // 5. Все остальное - пересылаем
			handlers.ForwardAndDeleteMessage(b.api, update.Message, b.cfg)
		}
	}
}