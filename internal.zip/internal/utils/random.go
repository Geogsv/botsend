package utils

import (
	"math/rand"
	"time"
)

func init() {
	// Инициализируем ГПСЧ один раз при загрузке пакета
	rand.Seed(time.Now().UnixNano())
}

// GetRandomString возвращает случайную строку из среза.
func GetRandomString(slice []string) string {
	if len(slice) == 0 {
		return ""
	}
	return slice[rand.Intn(len(slice))]
}